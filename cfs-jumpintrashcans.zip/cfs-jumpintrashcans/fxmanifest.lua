fx_version 'adamant'
games { 'gta5' }


author 'The Real Elchapo'
version '1.0.0'
lua54 'yes'

client_scripts {
    'client.lua',
}

shared_scripts {
    'config.lua',
    'en.lua'
}

escrow_ignore {
    'config.lua'
}

