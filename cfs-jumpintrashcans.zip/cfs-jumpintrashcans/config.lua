Config = {}
Config.Debug = true

Config.TrashCans = {
    Hash = {218085040,1748268526,-58485588, 666561306}, -- trash can model
    Distance = 1.5, -- target distance
}

