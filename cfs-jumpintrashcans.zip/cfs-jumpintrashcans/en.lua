

Lang = {
    Hide = "Jump inside.",
    Exit = "Jump Out.",
    NotInside = "Try Again.",
}