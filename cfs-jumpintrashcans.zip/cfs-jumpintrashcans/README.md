cfs-jumpintrashcans

drag and drop that simple enjoy :)
config . lua allows you to add more via hash numbers